package com.example.calendario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Acceder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceder);
    }
}